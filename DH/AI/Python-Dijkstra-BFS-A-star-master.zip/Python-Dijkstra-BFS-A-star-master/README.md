# Python-Dijkstra-BFS-A-star
examples of applying Dijkstra, BFS, A* in Pygame

![bfs](screenshot/1.png "bfs")
